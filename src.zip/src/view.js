import React from 'react';
import axios from 'axios';
import { useState ,useEffect} from "react";

function View(){
    const [renderdata, setrenderdata] = useState([{userid:""}]);
  const axios = require('axios');
    // const data = {};
    // console.log(data); 

    useEffect(async () => {
    const result = await axios(
      'http://jsonplaceholder.typicode.com/todos',
    );
    console.log(result.data);
     setrenderdata([result.data]);
  });


    // useEffect(() =>{

    // axios.get('http://jsonplaceholder.typicode.com/todos').then((response)=>{
    //     // setrenderdata([response[0].data])
    //         setrenderdata([response.data]);
    //         // console.log(renderdata);
            
    //     });
    // })

    

    const textList = renderdata.map(data => 
                                        (<h6>{data.title} </h6>) );

    return(
        <div>
           {textList}
        </div>
    );
}
export default View;