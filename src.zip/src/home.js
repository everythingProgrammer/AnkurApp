import React from 'react';

function Home(){
    return(
        <div>
            <h6> This is HomePage </h6>
        </div>
    )
}
export default Home;